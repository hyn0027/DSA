#include <cstdio>
#include <iostream>
#include <cstring>
#include <ctime>

inline int read() {
    int ret = 0;
    char c = getchar();
    while (c < '0' || c > '9')
        c = getchar();
    while (c >= '0' && c <= '9')
        ret = (ret << 1) + (ret << 3) + c - '0', c = getchar();
    return ret;
}

inline void write(int w) {
    if (w == 0) {
        putchar('0');
        return;
    }
    if (w < 0) {
        putchar('-');
        w = -w;
    }
    char my_out[20];
    unsigned short pt = 0;
    while (w) {
        my_out[pt++] = w % 10 + '0';
        w /= 10;
    }
    for (int i = pt - 1; i >= 0; i--) 
        putchar(my_out[i]);
}

void tree() {
    int len = rand() % 20 + 1;
    write(len);
    putchar(' ');
    write(0);
    putchar(' ');
    len--;
    while(len--) {
        write(rand() % 10);
        putchar(' ');
    }
    putchar('\n');
}

int main() {
    srand(time(0));
    int n = 500;
    int m = 500;
    write(n);
    putchar(' ');
    write(m);
    putchar('\n');
    for (int i = 1; i <= n; i++) {
        if (2 * i + 1 <= n) {
            write(2);
            putchar(' ');
            write(2 * i);
            putchar(' ');
            write(2 * i + 1);
            putchar('\n');
        }
        else if (2 * i <= n) {
            write(1);
            putchar(' ');
            write(2 * i);
            putchar('\n');
        }
        else {
            write(0);
            putchar('\n');
        }
    }
    while (m--) {
        int op = rand() % 3;
        if (op == 0) {
            putchar('0');
            putchar('\n');
            tree();
            tree();
            putchar('0');
            putchar('\n');
        }
        if (op == 1) {
            putchar('1');
            putchar('\n');
            tree();
        }
        if (op == 2) {
            putchar('2');
            putchar('\n');
            tree();
        }
    }
    return 0;
}